app.preferences.setBooleanPreference("ShowExternalJSXWarning", false);
